#Evalalgo3
Réaliser un "tableau" numbers composé de 10 case et contenant les valeurs suivantes :

2, 4, 1, 8, 6, 14, 23, 25, 7, 42

Creer un programme qui calcule et affiche :

- La moyenne des valeurs du tableau.
- Le résultat au carré de la valeur la plus grande du tableau.

```
VARIABLES :

- numbers est un tableau de 10 cases - entiers -
- totalSomme est un entier
- moyenne est un entier
- nbEleve est un entier
- leCarre est un entier

TRAITEMENT :

POUR l'addition des cases numbers /10 = moyenne
ECRIRE moyenne

ECRIRE 42*42 = Lecarre
Lire le Carre